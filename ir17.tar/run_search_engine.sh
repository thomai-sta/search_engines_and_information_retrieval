#!/bin/sh
java -cp classes:pdfbox -Xmx1g nlp.SearchGUI -d /info/DD2476/ir17/lab/davisWiki -l ir17.gif -p patterns.txt
